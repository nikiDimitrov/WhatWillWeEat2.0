﻿
namespace WhatWillWeEat2._0
{
    public partial class AddAllergenPage : ContentPage
    {
        public AddAllergenPage()
        {
            InitializeComponent();
        }
    }
}